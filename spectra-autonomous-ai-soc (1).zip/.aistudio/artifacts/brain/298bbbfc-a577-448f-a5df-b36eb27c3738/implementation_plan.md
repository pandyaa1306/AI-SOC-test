# FusionAI — Implementation Plan

## Executive Summary
**FusionAI** is an AI-powered intelligence, cross-platform correlation, and SOC operations platform designed for an Advanced Fusion Center. Sitting above fragmented security and IT tools (Google SecOps, Splunk, Exabeam, CrowdStrike, Microsoft Defender, Swimlane SOAR, ServiceNow ITSM), FusionAI normalizes telemetry into a Common Event Model (CEM) and orchestrates investigations without replacing human analysts.

---

## 1. Severity-Based Routing & The "FusionAI" Autonomous Investigator

### A. Low & Medium Severity Alerts: Autonomous FusionAI Triage & Report Generation
1. **Automated Ingestion & Acknowledgement**:
   - All Low and Medium severity alerts are instantly routed to the virtual investigator identified as **"FusionAI"**.
   - Initial acknowledgement is registered automatically within `< 3 seconds` with audit trail: `Acknowledged by FusionAI (AI-Powered Autonomous SOC Investigator)`.
2. **Autonomous Multi-Platform Correlation**:
   - FusionAI executes synthetic enrichment queries across Google SecOps, Splunk, Exabeam, CrowdStrike, and Network telemetry.
   - Status transitions to `In Progress (FusionAI Investigating)`.
3. **Comprehensive Analysis Report Generation**:
   - FusionAI attaches a detailed **FusionAI Analysis Report** directly to the case file:
     - Composite risk factor calculation (+points breakdown)
     - Multi-platform correlation rationale
     - Normalized timeline & MITRE ATT&CK mapping
     - Confidence score and recommended containment playbooks
4. **Manual Analyst Pickup ("Claim Alert")**:
   - Available analysts review the list of in-progress cases with pre-assembled FusionAI Analysis Reports.
   - Any available analyst can click **"Claim Alert / Assign to Me"**, which assigns the alert directly to their name, transitions status to `In Progress (Analyst Active)`, and starts their personal SLA/WIP timer.

### B. High & Critical Severity Alerts: Direct Human Dispatch
- High and Critical severity alerts bypass auto-holding and are **dispatched immediately to active human analysts** on Shift 1 for rapid hands-on triage and containment.
- In parallel, **FusionAI runs background cross-platform correlation** so that when the human analyst opens the alert, correlated graphs, timelines, and similar historical incidents are already pre-computed.

---

## 2. Model SOC: 6 Enterprise Clients & 18 Dedicated Analysts (Shift 1)

### A. 6 Enterprise Clients
1. **Apex Financial Group** (FINSERV, Criticality: Tier 1 Critical)
2. **Nexus Health Systems** (Healthcare / HIPAA, Criticality: High)
3. **AeroTech Defense Corp** (Aerospace / GovCloud, Criticality: Tier 1 Critical)
4. **Vanguard Retail Global** (E-Commerce / PCI-DSS, Criticality: Medium-High)
5. **OmniCloud Technologies** (SaaS / Multi-cloud, Criticality: High)
6. **Starlight Energy & Utilities** (Critical Infrastructure / OT-IT, Criticality: Tier 1 Critical)

### B. 18 Dedicated Human Analysts (Shift 1: Alpha Shift 08:00–16:00 UTC)
- **3 dedicated analysts per client**:
  - Tier 1: Triage Specialist (Initial review, alert claim, rapid containment)
  - Tier 2: Incident Responder (Deep-dive, cross-platform forensics, attack narrative)
  - Tier 3: Senior Threat Hunter (Advanced persistence analysis, rule tuning, root cause)
- Plus the virtual 19th entity: **FusionAI (Autonomous Virtual Investigator)**

---

## 3. Dedicated Dashboards & Capabilities

### Dashboard 1 — SOC Command Center
- **Executive Metrics**: Total Alerts (24h), Open Incidents, Critical/High backlog, SLA At-Risk count, Active WIP, Correlation Rate (%), Avg MTTI & MTTR, Automated Investigation Time Saved.
- **Client Fleet Health Grid**: Real-time snapshot of all 6 enterprise clients.
- **Live Alert Feed**: Real-time incoming alerts labeled with source platform (Google SecOps, Splunk, Exabeam, Defender, CrowdStrike), severity, routing target (`FusionAI` for Low/Med vs Direct Analyst for High/Crit), and 1-click **"Investigate with FusionAI"**.

### Dashboard 2 — SOC Analyst Operations & Workload Dashboard
- **Sortable Analyst Workload Table**:
  - View every analyst's name, assigned client name, tier, shift status, and caseload.
  - **Interactive Sorting**:
    - Sort by **Total Alerts/Tickets Owned** (High-to-Low `▼` or Low-to-High `▲`)
    - Sort by **WIP / In-Progress Cases** (High-to-Low or Low-to-High)
    - Sort by **SLA Risk Count** (High-to-Low)
    - Sort by **Analyst Name** (A-Z or Z-A)
    - Sort by **Client Name**
  - Columns: `Analyst Name` | `Client` | `Tier` | `Total Owned` | `WIP (Active)` | `Pending` | `Escalated` | `Critical` | `High` | `SLA At-Risk` | `Aging Breakdown (<2h, 2-4h, 4-8h, >8h)` | `Workload Status (Optimal / Normal / Overloaded)`.
- **Intelligent Workload Balancing Engine**:
  - Detects workload imbalance (e.g., Analyst A carrying 19 WIP with 3 SLA risks while Analyst B has 4 WIP and matching skills).
  - Recommends smart case reassignments requiring human manager approval.
- **Alert Fatigue & Rule Tuning Analytics**:
  - Analyzes rule dispositions (e.g. 10,000 alerts, 82% benign, 14% duplicate, 4% true positive) and generates rule tuning suggestions.

### Dashboard 3 — "My SOC" Analyst Personal Queue
- Focused workbench for the currently active human analyst.
- Displays:
  - Personal Work Queue: Assigned, In Progress, Pending, Escalated, SLA At-Risk, Aging breakdown.
  - **"Unclaimed FusionAI Triage Queue"**: Low/Med alerts investigated by FusionAI ready to be claimed with 1 click.
  - Active incident countdowns, immediate action checklists, and recent case notes.

### Dashboard 4 — FusionAI Investigation Workspace (Interactive Demo Scenario)
- Complete walk-through of a realistic multi-stage breach:
  - Origin: Google SecOps `Suspicious Authentication` alert.
  - Correlated platforms: Exabeam (user risk surge), Splunk (PowerShell execution), CrowdStrike EDR (suspicious process `lsass.exe` dump), Network (beaconing to suspicious C2 IP), Entra ID (MFA fatigue + OAuth consent).
- **Explainable AI Breakdown**:
  - Risk Score `87/100` with transparent point contributions (+25 Unusual auth, +20 New device, +15 Suspicious IP, +10 OAuth grant, +10 Mailbox rule, +7 Suspicious PowerShell).
  - Explicit correlation rationale: *"The same user (s.jenkins@apexfin.com) and source IP (185.220.101.45) were observed across Google SecOps, Exabeam and endpoint telemetry within 12 minutes."*
- **AI Attack Story**: Narrative progression distinguishing verified telemetry facts from AI assessments.
- **Institutional Memory**: 3 historical matching incidents with previous resolutions and response times.
- **ServiceNow Case Creation Flow**: Pre-populates incident title, client, CMDB asset, affected user/device, timeline, MITRE tags, and AI summary with analyst review and 1-click dispatch.
- **Swimlane SOAR Gated Approvals**: Playbook containment actions (Isolate Host, Revoke Entra ID Sessions, Block IP at Firewall, Disable Account) with strict human approval modals and live execution output.

### Dashboard 5 — Interactive Attack Graph
- Multi-entity graph: `User` → `IP Address` → `Device` → `Process` → `Network Connection` → `Application` → `Incident`.
- Interactive node inspection: Clicking any entity displays underlying platform telemetry, evidence logs, timestamps, and confidence scores.

---

## 4. Technology Stack & Verification
- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS + Lucide Icons + Motion animations.
- **AI Investigation**: Google GenAI SDK (`@google/genai` with `gemini-2.5-flash`) for live natural language SOC queries, root-cause syntheses, and executive reporting (with robust offline fallback for deterministic demo reliability).
- **Verification**: Zero errors via `compile_applet`, responsive multi-tab layout, seamless client/analyst switching, and live interactive state management.
